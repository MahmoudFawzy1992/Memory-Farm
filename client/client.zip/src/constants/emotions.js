export const emotions = [
  { label: 'All', emoji: '🌀', value: '' },
  { label: 'Happy', emoji: '😊' },
  { label: 'Sad', emoji: '😢' },
  { label: 'Angry', emoji: '😠' },
  { label: 'Surprised', emoji: '😱' },
  { label: 'Calm', emoji: '😌' },
  { label: 'Nostalgic', emoji: '🥺' },
]

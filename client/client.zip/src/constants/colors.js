const colorOptions = [
  { name: 'Purple', value: 'purple-500' },
  { name: 'Blue', value: 'blue-500' },
  { name: 'Green', value: 'green-500' },
  { name: 'Red', value: 'red-500' },
  { name: 'Yellow', value: 'yellow-500' },
]

export default colorOptions
